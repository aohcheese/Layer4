#include <stdlib.h>
#include <stdint.h>

#ifndef RANDOM_H
#define RANDOM_H

int random_bytes(void *dst, size_t n);

#endif
