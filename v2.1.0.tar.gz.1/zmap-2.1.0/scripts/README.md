These scripts are used by Travis CI  to prepare the build environment.

If you run them on your system, you should both

1. Trust me, because they need sudo
2. Run them from the parent directory, e.g. `./scripts/install_cmake.sh` 
